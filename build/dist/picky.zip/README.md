# Picky

[![npm (scoped)](https://img.shields.io/badge/npm-v6.4.1-blue.svg)](https://github.com/kaur01/picky)

Ready to use 

## Development server

Run `npm run devStart` for a dev server. Navigate to `http://localhost:4000/`.

##Production Build

Run `npm run start` for a production build. Navigate to `http://localhost:4000/`.

## Build

Run [gulp](https://www.npmjs.com/package/gulp-install) `build` to build and run the unit tests of the project.

## Running build without unit tests

Run `gulp assemble` to build without running unit tests.

## Running unit tests

Run `gulp test` to execute the unit tests via [Mocha](https://www.npmjs.com/package/mocha).

